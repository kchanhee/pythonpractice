
# States
NORMAL = 0
# {}
SAW_BRACES = 1
# []
SAW_BRACKETS = 2
# ""
SAW_QUOTES = 3
state_dict = {NORMAL:'NORMAL', SAW_BRACES:'SAW_BRACES', SAW_BRACKETS:'SAW_BRACKETS', SAW_QUOTES:'SAW_QUOTE'}
# char type:
TEXT = 0
COMMA = 1
QUOTE = 2
BRACE_LEFT = 3 # {}
BRACE_RIGHT = 4
BRACK_LEFT = 5 # []
BRACK_RIGHT = 6

class Solution:
    # @param A : string
    # @return a list of strings
    def prettyJSON(self, A):
        buff = ''
        final = []
        A = A.strip()
        state_stack = [NORMAL]
        
        left_brace_count = 0
        left_brack_count = 0
        for char in A:
            # print "final list: " + str(final)
            # print "CURRENT BUFFER IS: " + buff
            char_type = self.getCharType(char)
            state = state_stack[-1]
            state_list = []
            for i in state_stack:
                state_list.append(state_dict[i])
            # print ""
            # print "CURRENT STATE IS: " + state_dict[state]
            # print "--------------------------------------"
            if char == ' ':
                continue
            if state == NORMAL:
                if char_type == TEXT:
                    buff += char
                elif char_type == BRACE_LEFT:
                    state_stack.append(SAW_BRACES)
                    left_brace_count += 1
                    buff += char
                    final.append(buff)
                    buff = '\t'*left_brace_count
                elif char_type == BRACK_LEFT:
                    state_stack.append(SAW_BRACKETS)
                    left_brack_count += 1 
                    buff += char
                    final.append(buff)
                    buff = '\t'*left_brack_count
            elif state == SAW_QUOTES: # Escape everything until you see quotes again
                if char_type == QUOTE:
                    buff += char
                    # final.append(buff)
                    # # buff = ''
                    # buff = '\t' * (left_brack_count + left_brace_count)
                    state_stack.pop()
                else:
                    buff += char
            elif state == SAW_BRACES:
                if char_type == BRACK_LEFT:
                    # state = SAW_BRACKETS
                    if buff != '\t' * (left_brace_count + left_brack_count):
                        final.append(buff)
                    buff = '\t' * (left_brace_count + left_brack_count) + char
                    left_brack_count += 1 
                    final.append(buff)
                    buff = '\t' * (left_brack_count + left_brace_count)
                    state_stack.append(SAW_BRACKETS)
                elif char_type == BRACE_LEFT:
                    state_stack.append(SAW_BRACES)
                    if buff != '\t' * (left_brace_count + left_brack_count):
                        final.append(buff)
                    buff = '\t' * (left_brace_count + left_brack_count) + char
                    left_brace_count += 1
                    final.append(buff)
                    buff = '\t' * (left_brace_count + left_brack_count)
                elif char_type == BRACE_RIGHT:
                    left_brace_count -= 1
                    final.append(buff) # closing a brace => add w/e was saved to the list and reduce tabs
                    buff = '\t' * (left_brace_count + left_brack_count) + char
                    # final.append(buff)
                    state_stack.pop()
                elif char_type == TEXT:
                    buff += char
                elif char_type == QUOTE:
                    state_stack.append(SAW_QUOTES)
                    buff += char
                elif char_type == COMMA:
                    buff += char
                    final.append(buff)
                    buff = '\t' * (left_brack_count + left_brace_count)
            elif state == SAW_BRACKETS:
                if char_type == BRACE_LEFT:
                    state_stack.append(SAW_BRACES)
                    # print "BUFFER is " + buff
                    if buff != '\t' * (left_brace_count + left_brack_count):
                        # print 'should not add this -_-'
                        final.append(buff)
                    buff = '\t' * (left_brace_count + left_brack_count) + char
                    left_brace_count += 1
                    final.append(buff)
                    buff = '\t' * (left_brace_count + left_brack_count)
                elif char_type == BRACK_LEFT:
                    # state = SAW_BRACKETS
                    if buff != '\t' * (left_brace_count + left_brack_count):
                        final.append(buff)
                    buff = '\t' * (left_brace_count + left_brack_count) + char
                    left_brack_count += 1
                    final.append(buff)
                    buff = '\t' * (left_brack_count + left_brace_count)
                    state_stack.append(SAW_BRACKETS)
                elif char_type == BRACK_RIGHT:
                    left_brack_count -= 1
                    final.append(buff)
                    buff = '\t' * (left_brack_count + left_brace_count) + char
                    # final.append(buff)
                    state_stack.pop()
                elif char_type == TEXT:
                    buff += char
                elif char_type == QUOTE:
                    state_stack.append(SAW_QUOTES)
                    buff += char
                elif char_type == COMMA:
                    buff += char
                    final.append(buff)
                    buff = '\t' * (left_brack_count + left_brace_count)

        else:
            final.append(buff)
        return final

    def getCharType(self, char):
        if char == ",":
            return COMMA
        elif char == '"':
            return QUOTE
        elif char == "{" or char == "}":
            if char == "{":
                return BRACE_LEFT
            else:
                return BRACE_RIGHT
        elif char == "[" or char == "]":
            if char == "[":
                return BRACK_LEFT
            else:
                return BRACK_RIGHT
        else:
            return TEXT

def printL(L):
    for i in L:
        print i

# A = '{A:"B",C:{D:"E",F:{G:"H",I:"J"}}}'
# B = '["foo", {"bar":["baz",null,1.0,2]}]'
json = '[{"id":8796,"name":"Baller HQ","picture":null,"picture_retina":null,"city_name":"Pasadena","region_name":null,"country_name":null,"url_name":"baller-hq-8796","address":"844 E Green St","latitude":34.1443729872982,"longitude":-118.132605315014,"category_name":null,"category_short_name":null,"default_place":false,"distance":0.00973825249942762},{"id":8563,"name":"Braun Athletic Center","picture":"https://ss1.4sqi.net/img/categories_v2/building/gym_32.png","picture_retina":"https://ss1.4sqi.net/img/categories_v2/building/gym_64.png","city_name":"Pasadena","region_name":"CA","country_name":"united-states","url_name":"braun-athletic-center-pasadena-8563","address":"1200 E California Blvd","latitude":34.1340782701517,"longitude":-118.127231874299,"category_name":"Gym / Fitness Center","category_short_name":"Gym / Fitness","default_place":false,"distance":0.784439060417725}]'

s = Solution()
# x = s.prettyJSON(A)
y = s.prettyJSON(json)

printL(y)
